//
//  main.m
//  NSuserDefaults
//
//  Created by douxindong on 16/2/25.
//  Copyright © 2016年 douxindong. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //NSUserDefaults
        //1.文件存储
        //2.数据持久化的一种
        //酷狗音乐   针对自己的应用存储东西
        
        // NSUserDefaults 是一个 single
        //单例在我们的应用里边 都是唯一一个的存在
        //永久存在我们的应用的内存里
        //建议不要大量使用单例
        //用户点击登陆的那一霎那  把用户信息存起来
        //［点击登陆］
        //NSUserDefaults  他是以 key  － value  的方式进行存储数据
        //假设 cunchu一个字符串
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSUserDefaults *d2 = [NSUserDefaults standardUserDefaults];
        NSLog(@"%@ %@",defaults,d2);
        //设置了需要存储的数据
        [defaults setObject:@{@"userid":@"123456",@"password":@"mima"} forKey:@"userInfo"];
        [defaults setObject:@"Yes" forKey:@"isLogin"];
        [defaults synchronize];//立即同步存储
        //NSUserDefaults 他是一个数据持久化的方式的话 ，以plist文件格式存放
        NSDictionary *dic = [defaults objectForKey:@"userInfo"];
        NSLog(@"%@",dic);
    
    }
    
    return 0;
}
